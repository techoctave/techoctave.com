require 'test_helper'

class DraftsHelperTest < ActionView::TestCase
end
