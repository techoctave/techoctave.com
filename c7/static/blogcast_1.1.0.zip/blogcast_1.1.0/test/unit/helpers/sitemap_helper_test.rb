require 'test_helper'

class SitemapHelperTest < ActionView::TestCase
end
