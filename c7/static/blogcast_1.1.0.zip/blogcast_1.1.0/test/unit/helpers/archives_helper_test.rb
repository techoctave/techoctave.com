require 'test_helper'

class ArchivesHelperTest < ActionView::TestCase
end
