require 'test_helper'

class AkismetHelperTest < ActionView::TestCase
end
