require 'test_helper'

class LoginsHelperTest < ActionView::TestCase
end
