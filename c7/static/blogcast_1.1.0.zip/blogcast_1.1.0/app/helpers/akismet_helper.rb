module AkismetHelper
end
