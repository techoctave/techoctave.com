module DraftsHelper
end
