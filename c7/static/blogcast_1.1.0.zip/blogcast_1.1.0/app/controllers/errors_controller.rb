class ErrorsController < ApplicationController
  def routing
    render_404
  end
end