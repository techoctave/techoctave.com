# config/initializers/mail.rb

ActionMailer::Base.delivery_method = :smtp
ActionMailer::Base.smtp_settings = {
	:address => "mail.example-domain.com",
	:port => 25,
	:domain => "www.example-domain.com",
	:authentication => :login,
	:user_name => "user@example-domain.com",
	:password => "secret"
}