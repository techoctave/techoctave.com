# Object Oriented Ruby: Classes, Mixins and Jedi
# http://techoctave.com/c7/posts/46-object-oriented-ruby-classes-mixins-and-jedi
#
# Copyright (c) 2011 by Tian Valdemar Davis
# Licensed under the MIT (http://en.wikipedia.org/wiki/MIT_License) license.
require 'Force'
require 'Lightsaber'

class Padawan
  attr_accessor :name
  
  include Force
  include Lightsaber
  
  def inspect
    puts "Force-Sensitive: " + @name
  end
end