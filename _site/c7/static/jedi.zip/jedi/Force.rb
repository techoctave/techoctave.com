# Object Oriented Ruby: Classes, Mixins and Jedi
# http://techoctave.com/c7/posts/46-object-oriented-ruby-classes-mixins-and-jedi
#
# Copyright (c) 2011 by Tian Valdemar Davis
# Licensed under the MIT (http://en.wikipedia.org/wiki/MIT_License) license.
module Force
  def mindtrick
  end
  
  def levitation
    puts "Force.levitation"
  end
  
  def choke
  end
  
  def lighting
  end
  
  def deflection
  end
end