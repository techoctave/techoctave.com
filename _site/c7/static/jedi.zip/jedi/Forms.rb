# Object Oriented Ruby: Classes, Mixins and Jedi
# http://techoctave.com/c7/posts/46-object-oriented-ruby-classes-mixins-and-jedi
#
# Copyright (c) 2011 by Tian Valdemar Davis
# Licensed under the MIT (http://en.wikipedia.org/wiki/MIT_License) license.
module Forms
  def shiicho
  end
  
  def makashi
  end
  
  def soresu
  end
  
  def ataru
  end
  
  def shien
  end
  
  def niman
  end
  
  def juyo
    puts "Forms.juyo"
  end
  
  def vaapad
  end
end